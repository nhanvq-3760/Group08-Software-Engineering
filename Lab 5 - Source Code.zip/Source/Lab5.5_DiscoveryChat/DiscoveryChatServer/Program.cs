using System.Collections.Concurrent;
using System.Net;
using System.Net.Sockets;
using System.Text;

const int ChatPort = 5000;
const int DiscoveryPort = 5001;
const string Request = "DISCOVER_CHAT_SERVER_V1";
const string Response = "CHAT_SERVER_V1";
var sessions = new ConcurrentDictionary<int, ClientSession>();
int lastId = 0;
var listener = new TcpListener(IPAddress.Any, ChatPort);
listener.Start();
using var udp = new UdpClient(new IPEndPoint(IPAddress.Any, DiscoveryPort));
Console.WriteLine($"Chat on TCP {ChatPort}; discovery on UDP {DiscoveryPort}.");
_ = DiscoveryLoopAsync();
while (true)
{
    TcpClient tcp = await listener.AcceptTcpClientAsync();
    int id = Interlocked.Increment(ref lastId);
    var session = new ClientSession(id, tcp);
    sessions[id] = session;
    _ = HandleAsync(session);
}

async Task DiscoveryLoopAsync()
{
    while (true)
    {
        try
        {
            UdpReceiveResult packet = await udp.ReceiveAsync();
            if (Encoding.UTF8.GetString(packet.Buffer) != Request) continue;
            // Send only the service port; the client uses the IP of the reply sender.
            byte[] answer = Encoding.UTF8.GetBytes($"{Response}|{ChatPort}");
            await udp.SendAsync(answer, packet.RemoteEndPoint);
            Console.WriteLine($"Discovery reply to {packet.RemoteEndPoint}");
        }
        catch (SocketException ex) { Console.WriteLine($"UDP error: {ex.SocketErrorCode}"); }
    }
}

async Task HandleAsync(ClientSession who)
{
    try
    {
        await who.SendAsync($"WELCOME Client {who.Id}");
        await BroadcastAsync($"SYSTEM Client {who.Id} joined");
        using var reader = new StreamReader(who.Tcp.GetStream(), Encoding.UTF8, false, 4096, true);
        while (true)
        {
            string? line = await reader.ReadLineAsync();
            if (line is null || line == "/quit") break;
            if (line.Length == 0) continue;
            if (line.Length > 1000) { await who.SendAsync("ERROR message too long"); continue; }
            await BroadcastAsync($"Client {who.Id}: {line}");
        }
    }
    catch (IOException) { }
    catch (SocketException) { }
    catch (ObjectDisposedException) { }
    finally
    {
        sessions.TryRemove(who.Id, out _);
        who.Dispose();
        await BroadcastAsync($"SYSTEM Client {who.Id} left");
    }
}

async Task BroadcastAsync(string line)
{
    foreach (ClientSession target in sessions.Values)
    {
        try { await target.SendAsync(line); }
        catch (IOException) { target.Dispose(); }
        catch (ObjectDisposedException) { }
    }
}

sealed class ClientSession : IDisposable
{
    public int Id { get; }
    public TcpClient Tcp { get; }
    private readonly StreamWriter writer;
    private readonly SemaphoreSlim gate = new(1, 1);
    public ClientSession(int id, TcpClient tcp)
    {
        Id = id;
        Tcp = tcp;
        writer = new StreamWriter(tcp.GetStream(), new UTF8Encoding(false), 4096, true)
        { AutoFlush = true };
    }
    public async Task SendAsync(string line)
    {
        await gate.WaitAsync();
        try { await writer.WriteLineAsync(line); }
        finally { gate.Release(); }
    }
    public void Dispose() => Tcp.Dispose();
}
