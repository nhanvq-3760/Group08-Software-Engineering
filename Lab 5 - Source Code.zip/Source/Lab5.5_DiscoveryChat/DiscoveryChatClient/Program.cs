using System.Net;
using System.Net.Sockets;
using System.Text;

const int DiscoveryPort = 5001;
const string Request = "DISCOVER_CHAT_SERVER_V1";
const string Response = "CHAT_SERVER_V1";
using var udp = new UdpClient(AddressFamily.InterNetwork);
udp.EnableBroadcast = true;
byte[] requestBytes = Encoding.UTF8.GetBytes(Request);
Console.WriteLine("Looking for a local chat server...");
await udp.SendAsync(requestBytes, new IPEndPoint(IPAddress.Broadcast, DiscoveryPort));
// Some platforms do not route limited broadcast over loopback. For testing on one computer,
// send an additional loopback datagram. The real LAN discovery still uses broadcast.
await udp.SendAsync(requestBytes, new IPEndPoint(IPAddress.Loopback, DiscoveryPort));
IPEndPoint? serverEndpoint = null;
using var timeout = new CancellationTokenSource(TimeSpan.FromSeconds(5));
try
{
    while (!timeout.IsCancellationRequested)
    {
        UdpReceiveResult response = await udp.ReceiveAsync(timeout.Token);
        string[] fields = Encoding.UTF8.GetString(response.Buffer).Split('|');
        if (fields.Length != 2 || fields[0] != Response || !int.TryParse(fields[1], out int port)
            || port is < 1 or > 65535) continue;
        // Local example only: do not trust arbitrary discovery replies on untrusted networks.
        serverEndpoint = new IPEndPoint(response.RemoteEndPoint.Address, port);
        break;
    }
}
catch (OperationCanceledException) { }
if (serverEndpoint is null)
{
    Console.WriteLine("No server found within 5 seconds. Check server, firewall and subnet.");
    return;
}
Console.WriteLine($"Discovered {serverEndpoint}");
using var tcp = new TcpClient(serverEndpoint.AddressFamily);
try { await tcp.ConnectAsync(serverEndpoint.Address, serverEndpoint.Port); }
catch (SocketException ex) { Console.WriteLine($"Could not connect: {ex.SocketErrorCode}"); return; }
Console.WriteLine("Chat connected. Type messages, /quit to exit.");
using var reader = new StreamReader(tcp.GetStream(), Encoding.UTF8, false, 4096, true);
using var writer = new StreamWriter(tcp.GetStream(), new UTF8Encoding(false), 4096, true)
{ AutoFlush = true };
using var stop = new CancellationTokenSource();
Task receiveTask = Task.Run(async () =>
{
    try
    {
        while (true)
        {
            string? line = await reader.ReadLineAsync(stop.Token);
            if (line is null) { Console.WriteLine("Server disconnected."); break; }
            Console.WriteLine(line);
        }
    }
    catch (OperationCanceledException) { }
    catch (IOException) { Console.WriteLine("Chat connection lost."); }
});
try
{
    while (true)
    {
        string? line = Console.ReadLine();
        if (line is null || line == "/quit") break;
        await writer.WriteLineAsync(line);
    }
}
catch (IOException) { Console.WriteLine("Send failed."); }
finally { stop.Cancel(); tcp.Close(); await receiveTask; }
