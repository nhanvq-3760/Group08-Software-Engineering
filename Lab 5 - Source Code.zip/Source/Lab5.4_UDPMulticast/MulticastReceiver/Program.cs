using System.Net;
using System.Net.Sockets;
using System.Text;

var group = IPAddress.Parse("239.0.0.222");
const int Port = 5004;
using var udp = new UdpClient(AddressFamily.InterNetwork);
udp.Client.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReuseAddress, true);
udp.Client.Bind(new IPEndPoint(IPAddress.Any, Port));
udp.JoinMulticastGroup(group);
Console.WriteLine($"Joined multicast group {group}:{Port}. Ctrl+C to exit.");
try
{
    while (true)
    {
        UdpReceiveResult msg = await udp.ReceiveAsync();
        Console.WriteLine($"From {msg.RemoteEndPoint}: {Encoding.UTF8.GetString(msg.Buffer)}");
    }
}
finally { udp.DropMulticastGroup(group); }
