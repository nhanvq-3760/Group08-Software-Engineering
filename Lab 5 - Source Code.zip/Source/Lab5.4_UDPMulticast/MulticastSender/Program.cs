using System.Net;
using System.Net.Sockets;
using System.Text;

var group = IPAddress.Parse("239.0.0.222");
const int Port = 5004;
using var udp = new UdpClient(AddressFamily.InterNetwork);
udp.MulticastLoopback = true; // Enables local-loopback testing where OS supports it.
udp.Ttl = 1; // Stay within the local network.
Console.WriteLine($"Publishing to {group}:{Port}; /quit to stop.");
while (true)
{
    string? line = Console.ReadLine();
    if (line is null || line == "/quit") break;
    await udp.SendAsync(Encoding.UTF8.GetBytes(line), new IPEndPoint(group, Port));
    Console.WriteLine("Multicast datagram sent (not an acknowledgment).");
}
