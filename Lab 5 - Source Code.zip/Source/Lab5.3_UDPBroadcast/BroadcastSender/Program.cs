using System.Net;
using System.Net.Sockets;
using System.Text;

const int Port = 5003;
using var udp = new UdpClient(AddressFamily.InterNetwork);
udp.EnableBroadcast = true;
Console.WriteLine("Type message to broadcast, /quit to stop.");
while (true)
{
    string? message = Console.ReadLine();
    if (message is null || message == "/quit") break;
    byte[] payload = Encoding.UTF8.GetBytes(message);
    int bytes = await udp.SendAsync(payload, new IPEndPoint(IPAddress.Broadcast, Port));
    Console.WriteLine($"Sent UDP broadcast ({bytes} bytes). Delivery not guaranteed.");
}
