using System.Net;
using System.Net.Sockets;
using System.Text;

const int Port = 5003;
using var udp = new UdpClient(new IPEndPoint(IPAddress.Any, Port));
Console.WriteLine($"UDP broadcast receiver listening on port {Port}");
while (true)
{
    UdpReceiveResult packet = await udp.ReceiveAsync();
    Console.WriteLine($"From {packet.RemoteEndPoint}: " + Encoding.UTF8.GetString(packet.Buffer));
}
