using System.Net;
using System.Net.Sockets;
using System.Text;

using var socket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
await socket.ConnectAsync(IPAddress.Loopback, 5000);
Console.WriteLine($"Connected: {socket.LocalEndPoint} -> {socket.RemoteEndPoint}");
Console.WriteLine("Type a short message or /quit. An echo is returned.");
while (true)
{
    string? line = Console.ReadLine();
    if (line is null || line == "/quit") break;
    byte[] payload = Encoding.UTF8.GetBytes(line);
    // Short educational messages; SendAsync is not assumed to send the entire buffer.
    int offset = 0;
    while (offset < payload.Length)
    {
        int sent = await socket.SendAsync(payload.AsMemory(offset), SocketFlags.None);
        if (sent == 0) throw new IOException("Socket closed during send.");
        offset += sent;
    }
    byte[] response = new byte[payload.Length];
    int read = 0;
    while (read < response.Length)
    {
        int n = await socket.ReceiveAsync(response.AsMemory(read), SocketFlags.None);
        if (n == 0) throw new IOException("Server disconnected.");
        read += n;
    }
    Console.WriteLine("Echo: " + Encoding.UTF8.GetString(response));
}
socket.Shutdown(SocketShutdown.Both);
