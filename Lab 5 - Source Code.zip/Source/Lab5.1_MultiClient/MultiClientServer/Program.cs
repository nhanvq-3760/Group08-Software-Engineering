using System.Net;
using System.Net.Sockets;
using System.Text;

using var listener = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
listener.Bind(new IPEndPoint(IPAddress.Loopback, 5000));
listener.Listen(100);
Console.WriteLine("Lab 5.1 server listening on 127.0.0.1:5000");
while (true)
{
    Socket client = await listener.AcceptAsync();
    Console.WriteLine($"Accepted {client.RemoteEndPoint}");
    _ = HandleClientAsync(client); // Independent async session; no blocking in accept loop.
}

static async Task HandleClientAsync(Socket client)
{
    using (client)
    {
        try
        {
            byte[] buffer = new byte[4096];
            while (true)
            {
                int n = await client.ReceiveAsync(buffer, SocketFlags.None);
                if (n == 0) break; // Graceful peer shutdown.
                Console.WriteLine($"[{client.RemoteEndPoint}] received {n} bytes: " +
                                  Convert.ToHexString(buffer.AsSpan(0, n)));
                // TCP is a byte stream: one receive is not necessarily one message.
                await client.SendAsync(buffer.AsMemory(0, n), SocketFlags.None);
            }
        }
        catch (SocketException ex) { Console.WriteLine($"Socket error: {ex.SocketErrorCode}"); }
        catch (IOException ex) { Console.WriteLine($"I/O error: {ex.Message}"); }
        finally { Console.WriteLine("Client disconnected"); }
    }
}
