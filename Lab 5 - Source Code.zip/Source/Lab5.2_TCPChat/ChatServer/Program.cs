using System.Collections.Concurrent;
using System.Net;
using System.Net.Sockets;
using System.Text;

const int Port = 5000;
var clients = new ConcurrentDictionary<int, Session>();
int nextId = 0;
var listener = new TcpListener(IPAddress.Loopback, Port);
listener.Start();
Console.WriteLine($"Lab 5.2 chat server listening on 127.0.0.1:{Port}");
while (true)
{
    TcpClient tcp = await listener.AcceptTcpClientAsync();
    int id = Interlocked.Increment(ref nextId);
    var session = new Session(id, tcp);
    clients[id] = session;
    Console.WriteLine($"Client {id} joined; online: {clients.Count}");
    _ = HandleAsync(session);
}

async Task HandleAsync(Session session)
{
    try
    {
        await session.SendAsync($"WELCOME {session.Id}. /quit to exit.");
        await BroadcastAsync($"SYSTEM Client {session.Id} joined.");
        // StreamReader.ReadLineAsync is the message framing mechanism (newline delimiter).
        // UTF8, bounded line size is a recommended production extension.
        using var reader = new StreamReader(session.Tcp.GetStream(), Encoding.UTF8,
                                            detectEncodingFromByteOrderMarks: false,
                                            bufferSize: 4096, leaveOpen: true);
        while (true)
        {
            string? line = await reader.ReadLineAsync();
            if (line is null || line == "/quit") break;
            if (line.Length == 0) continue;
            if (line.Length > 1000) { await session.SendAsync("ERROR Message too long."); continue; }
            Console.WriteLine($"[{session.Id}] {line}");
            await BroadcastAsync($"Client {session.Id}: {line}");
        }
    }
    catch (IOException) { /* Client disconnected or network failed. */ }
    catch (SocketException) { /* Connection reset. */ }
    catch (ObjectDisposedException) { /* Connection closed. */ }
    finally
    {
        clients.TryRemove(session.Id, out _);
        session.Dispose();
        Console.WriteLine($"Client {session.Id} left; online: {clients.Count}");
        await BroadcastAsync($"SYSTEM Client {session.Id} left.");
    }
}

async Task BroadcastAsync(string message)
{
    // Snapshot makes concurrent registry updates safe; failing peers are removed by their handler.
    foreach (Session target in clients.Values)
    {
        try { await target.SendAsync(message); }
        catch (IOException) { target.Dispose(); }
        catch (ObjectDisposedException) { /* Target exited. */ }
    }
}

sealed class Session : IDisposable
{
    public int Id { get; }
    public TcpClient Tcp { get; }
    private readonly StreamWriter writer;
    private readonly SemaphoreSlim writeLock = new(1, 1);
    public Session(int id, TcpClient tcp)
    {
        Id = id;
        Tcp = tcp;
        writer = new StreamWriter(tcp.GetStream(), new UTF8Encoding(false), 4096,
                                  leaveOpen: true) { AutoFlush = true };
    }
    public async Task SendAsync(string message)
    {
        await writeLock.WaitAsync();
        try { await writer.WriteLineAsync(message); }
        finally { writeLock.Release(); }
    }
    public void Dispose() { Tcp.Dispose(); /* Lock kept alive for in-flight writes. */ }
}
