using System.Net.Sockets;
using System.Text;

using var client = new TcpClient();
await client.ConnectAsync("127.0.0.1", 5000);
Console.WriteLine("Chat connected. Type lines, /quit to exit.");
using var reader = new StreamReader(client.GetStream(), Encoding.UTF8,
    detectEncodingFromByteOrderMarks: false, bufferSize: 4096, leaveOpen: true);
using var writer = new StreamWriter(client.GetStream(), new UTF8Encoding(false),
    4096, leaveOpen: true) { AutoFlush = true };
using var stop = new CancellationTokenSource();
var receiving = Task.Run(async () =>
{
    try
    {
        while (!stop.IsCancellationRequested)
        {
            string? line = await reader.ReadLineAsync(stop.Token);
            if (line is null) { Console.WriteLine("Server closed connection."); break; }
            Console.WriteLine(line);
        }
    }
    catch (OperationCanceledException) { }
    catch (IOException) { Console.WriteLine("Disconnected."); }
});
try
{
    while (true)
    {
        string? line = Console.ReadLine();
        if (line is null || line == "/quit") break;
        await writer.WriteLineAsync(line);
    }
}
catch (IOException) { Console.WriteLine("Unable to send: disconnected."); }
finally { stop.Cancel(); client.Close(); await receiving; }
